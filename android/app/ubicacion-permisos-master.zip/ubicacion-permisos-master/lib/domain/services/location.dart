abstract class LocationInterface {
  Future<void> getCurrentLocation();
}
